package com.example.frasesdodia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        }

    public void gerarNovaFrase (View view){

        String[] frases = {
                "\"A persistência é o caminho do êxito.\" - Charles Chaplin",
                "\"A vida é uma peça de teatro que não permite ensaios.\" - Mário Quintana",
                "\"O sucesso é a soma de pequenos esforços repetidos dia após dia.\" - Robert Collier",
                "\"O único lugar onde o sucesso vem antes do trabalho é no dicionário.\" - Vidal Sassoon",
                "\"A felicidade não é algo pronto. Ela é feita das suas próprias ações.\" - Dalai Lama",
                "\"O segredo da criatividade está em saber como esconder suas fontes.\" - Albert Einstein",
                "\"Acredite em si mesmo e tudo será possível.\" - Albert Einstein",
                "\"O sucesso é a soma de pequenos esforços repetidos dia após dia.\" - Robert Collier",
                "\"Não espere por uma crise para descobrir o que é importante em sua vida.\" - Platão",
                "\"O importante não é vencer todos os dias, mas lutar sempre.\" - Waldemar Valle Martins"
        };
        int numero = new Random().nextInt(4);

        TextView texto = findViewById(R.id.textView);
        texto.setText( frases[numero] );

    }
}
