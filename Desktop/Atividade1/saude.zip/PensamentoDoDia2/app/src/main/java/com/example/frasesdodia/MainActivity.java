package com.example.frasesdodia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        }

    public void gerarNovaFrase (View view){

        String[] frases = {
                "Mantenha uma dieta equilibrada, rica em frutas, vegetais, grãos integrais, proteínas magras e gorduras saudáveis.",
                "Mantenha-se hidratado, bebendo bastante água ao longo do dia.",
                "Pratique atividades físicas regularmente, como caminhadas, corridas, natação, yoga ou musculação, de acordo com suas preferências e condições físicas.",
                "Durma bem, garantindo de 7 a 9 horas de sono por noite para um descanso adequado.",
                "Evite fumar e limite o consumo de álcool.",
                "Faça exames médicos regulares para verificar sua saúde geral, pressão arterial, colesterol, glicemia, entre outros.",
                "Mantenha um peso saudável, evitando o sobrepeso e a obesidade.",
                "Reduza o estresse em sua vida, praticando técnicas de relaxamento, meditação ou atividades que você goste.",
                "Lave as mãos regularmente para evitar a propagação de germes e infecções.",
                "Mantenha-se socialmente conectado, pois relacionamentos positivos podem ter um impacto significativo na saúde mental e emocional."
        };
        int numero = new Random().nextInt(4);

        TextView texto = findViewById(R.id.textView);
        texto.setText( frases[numero] );

    }
}
