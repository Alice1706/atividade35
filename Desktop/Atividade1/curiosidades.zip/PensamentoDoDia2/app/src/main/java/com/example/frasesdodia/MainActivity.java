package com.example.frasesdodia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        }

    public void gerarNovaFrase (View view){

        String[] frases = {
                "O DNA humano é 99,9% idêntico entre todas as pessoas, mas o 0,1% restante é responsável por criar a diversidade única de cada indivíduo.",
                "O número de árvores na Terra é estimado em cerca de 3 trilhões, superando o número de estrelas na Via Láctea.",
                "Ostras podem mudar de sexo uma ou mais vezes durante sua vida, dependendo das condições ambientais e da disponibilidade de parceiros.",
                "O músculo mais forte do corpo humano é a língua.",
                "A Antártida é o único continente sem uma população nativa permanente.",
                "O olho humano é capaz de distinguir cerca de 10 milhões de cores.",
                "Os elefantes são os únicos mamíferos que não conseguem pular.",
                "As formigas são capazes de carregar objetos até 50 vezes mais pesados do que elas próprias.",
                "A girafa tem o mesmo número de vértebras no pescoço que um ser humano, apesar do comprimento muito maior do pescoço da girafa.",
                "Cada floco de neve é único, com sua própria forma e padrão de cristal de gelo."
        };
        int numero = new Random().nextInt(4);

        TextView texto = findViewById(R.id.textView);
        texto.setText( frases[numero] );

    }
}
