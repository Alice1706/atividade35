package com.example.frasesdodia;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        }

    public void gerarNovaFrase (View view){

        String[] frases = {
                "Lasanha",
                "Sushi.",
                "Feijoada",
                "Pizza",
                "Salada Caesar",
                "Tacos",
                "Curry de frango",
                "Risoto de cogumelos",
                "Hambúrguer gourmet",
                "Sorvete de chocolate"
        };
        int numero = new Random().nextInt(4);

        TextView texto = findViewById(R.id.textView);
        texto.setText( frases[numero] );

    }
}
